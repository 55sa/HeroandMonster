package Entity.Items;

// Item enum
public enum Type {
    ARMOR, SPELL, WEAPON, POTION
}
