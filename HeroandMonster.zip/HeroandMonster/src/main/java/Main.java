import Controller.MainEvent;
import Entity.Human.Hero;
import Entity.Items.Item;
import Entity.Items.Type;
import Entity.Monster.Monster;
import Repository.*;

import java.util.HashMap;

// Main access
public class Main {


public static void main(String[] args){
    MainEvent game =new MainEvent();
    game.Start();

}

}
